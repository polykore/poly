#~sudo

import subprocess
import os


def run(term, args):

    if not args:
        term.write(
            "Usage: sudo <command>"
        )
        return


    command = " ".join(args)


    term.write(
        f"[sudo] Running: {command}"
    )


    try:

        result = subprocess.run(

            command,

            shell=True,

            cwd=term.cwd,

            capture_output=True,

            text=True

        )


        if result.stdout:

            term.write(
                result.stdout
            )


        if result.stderr:

            term.write(
                result.stderr
            )


    except Exception as e:

        term.write(
            str(e)
        )
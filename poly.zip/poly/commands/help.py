def run(term, args):

    term.write("""
========================
Python Terminal Commands
========================

General
-------
help
clear
exit
history
time

Filesystem
----------
pwd
cd
ls
mkdir
touch
cat
cp
mv
rm

Variables
---------
set
get

Shell
-----
cmd
bash
shell

Examples
--------
ls
cd Documents
mkdir Test
touch hello.txt
cat hello.txt
""")
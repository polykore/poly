#~run

import os
import subprocess
import threading
import time
import tkinter as tk
import ctypes
import shutil


COMPATIBILITY = {
    "WIN98": "WIN98",
    "WINXPSP3": "WINXPSP3",
    "WIN7RTM": "WIN7RTM"
}



def find_program(app):

    #~full PATH
    if os.path.exists(app):
        return app


    #~search PATH
    found = shutil.which(app)

    if found:
        return found


    #~try exe
    if not app.lower().endswith(".exe"):

        found = shutil.which(
            app + ".exe"
        )

        if found:
            return found


    return None




def admin_launch(path):

    ctypes.windll.shell32.ShellExecuteW(
        None,
        "runas",
        path,
        None,
        None,
        1
    )




def debug_window():

    window = tk.Toplevel()

    window.title(
        "Run Debug Monitor"
    )

    window.geometry(
        "700x400"
    )


    output = tk.Text(
        window,
        bg="#050505",
        fg="#00ff88"
    )


    output.pack(
        fill="both",
        expand=True
    )


    return output




def debug_stream(box, process):

    for line in iter(
        process.stdout.readline,
        ""
    ):

        box.insert(
            tk.END,
            line
        )

        box.see(
            tk.END
        )




def run(term, args):


    if not args:

        term.write(
"""
Usage:

run <app> [flags]

Flags:

sudo
    Run as administrator

--comp VERSION
    Compatibility mode

    WIN98
    WINXPSP3
    WIN7RTM

--win COUNT
    Open multiple copies

--debug Y
    Live debug window
"""
        )

        return



    app = args[0]

    flags = args[1:]


    app_path = find_program(app)



    if not app_path:

        term.write(
            f"Cannot find {app}"
        )

        return




    admin = False

    compatibility = None

    instances = 1

    debug = False




    i = 0


    while i < len(flags):


        flag = flags[i].lower()



        if flag == "sudo":

            admin = True



        elif flag == "--comp":

            if i + 1 < len(flags):

                compatibility = flags[i + 1].upper()

                i += 1



        elif flag == "--win":

            if i + 1 < len(flags):

                try:

                    instances = int(
                        flags[i + 1]
                    )

                except:

                    instances = 1

                i += 1



        elif flag == "--debug":

            if i + 1 < len(flags):

                debug = (
                    flags[i + 1].upper()
                    ==
                    "Y"
                )

                i += 1



        i += 1




    #~sudo

    if admin:

        term.write(
            "Requesting administrator privileges..."
        )

        admin_launch(
            app_path
        )

        return





    env = os.environ.copy()



    #~compatability

    if compatibility:


        if compatibility in COMPATIBILITY:


            env[
                "__COMPAT_LAYER"
            ] = COMPATIBILITY[compatibility]


            term.write(
                f"Compatibility mode: {compatibility}"
            )


        else:

            term.write(
                f"Unknown compatibility mode: {compatibility}"
            )





    #~launch

    for number in range(instances):


        try:


            if debug:


                box = debug_window()


                process = subprocess.Popen(

                    [
                        app_path
                    ],

                    stdout=subprocess.PIPE,

                    stderr=subprocess.STDOUT,

                    text=True,

                    env=env

                )


                threading.Thread(

                    target=debug_stream,

                    args=(
                        box,
                        process
                    ),

                    daemon=True

                ).start()



            else:


                subprocess.Popen(

                    [
                        app_path
                    ],

                    env=env

                )



            term.write(

                f"Started {app_path} ({number + 1}/{instances})"

            )



        except Exception as e:


            term.write(

                f"Launch error: {e}"

            )



        time.sleep(
            0.2
        )
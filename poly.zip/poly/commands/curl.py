#~curl

import urllib.request


def run(term, args):

    if not args:

        term.write(
            "Usage: curl <url>"
        )

        return


    url = args[0]


    try:

        term.write(
            f"Fetching {url}..."
        )


        response = urllib.request.urlopen(
            url
        )


        data = response.read().decode(
            "utf-8",
            errors="ignore"
        )


        term.write(
            data
        )


    except Exception as e:

        term.write(
            f"curl error: {e}"
        )